library(DRHotNet)
library(lubridate)
library(maptools)
library(raster)
library(rgeos)
library(sp)
library(spatstat.core)
library(spatstat.linnet)
library(spdep)
library(SpNetPrep)
library(tigris)

# Set working directory

my_directory="Enter your working directory"
setwd(my_directory)

###################################################################################################################
# Basic example of a marked point pattern on a linear network
###################################################################################################################

x <- runif(100, 0, 1)
y <- runif(100, 0, 1)
simplenet.lpp <- lpp(data.frame(x, y), simplenet)

random_cont_mark <- rnorm(100, 0, 1)
random_cat_mark <- letters[round(runif(100, 0, 5))+1]
simplenet.lpp <- lpp(data.frame(x, y, random_cont_mark, random_cat_mark), 
                       simplenet)

###################################################################################################################
# Downloading and preparing the linear network from Chicago
###################################################################################################################

# Download Cook census tracts and road network structure

cook.tracts <- tracts(state = "IL", county = "031", class = "sp")
class(cook.tracts)
length(cook.tracts)
cook.network <- roads(state = "IL", county = "031", year = 2011, class = "sp")
class(cook.network)
length(cook.network)

# Filter Chicago Community Area

names.tracts <- as.character(cook.tracts@data[,"NAME"])
select.tracts <- c("8378","2804","8330","2801","2808","2809","8380","8381","8331",
                   "2819","2827","2828","8382","8329","2831","2832","8333","8419",
                   "8429","2838")
cook.tracts.select <- cook.tracts[which(names.tracts%in%select.tracts),]
chicago.SpLines <- intersect(cook.network, cook.tracts.select)
length(chicago.SpLines)

# Convert area and network to UTM (zone 16)

chicago.SpLines <- spTransform(chicago.SpLines, "+proj=utm +zone=16 ellps=WGS84")
class(chicago.SpLines)
length(chicago.SpLines)

# Convert to linnet

chicago.linnet <- as.linnet(chicago.SpLines)
class(chicago.linnet)

# Verifiy connectedness

table(connected(chicago.linnet, what = "labels"))
chicago.linnet.components <- connected(chicago.linnet, what = "components")
chicago.linnet.components[[1]]
chicago.linnet <- chicago.linnet.components[[1]]

# Figure 1

setEPS()
postscript(paste0("Figure1.eps"), family="Times")
par(mar=c(0,0,0,0))
plot(chicago.SpLines,col="#808080")
# Convert to UTM
chicago_utm <- spTransform(cook.tracts.select, "+proj=utm +zone=16 ellps=WGS84")
plot(chicago_utm,border="black",lwd=4,add=T)
scalebar(1000, xy=NULL, type='bar', divs=4, label = c("0 m","500 m","1000 m"))
dev.off()

# Figure 2a

setEPS()
postscript(paste0("Figure2a.eps"), family="Times")
par(mar=c(0,0,0,0))

aux_point=data.frame(x=445466.4,y=4636306)
coordinates(aux_point)=~x+y
proj4string(aux_point)=proj4string(chicago.SpLines)

square=gBuffer(aux_point,width = 300,capStyle="SQUARE")

network_square=intersect(chicago.SpLines,square)
plot(network_square,col="#808080")
vertices_network=vertices(chicago.linnet)
vertices_network=as(vertices_network,"SpatialPoints")
intersection_points=intersect(vertices_network,square)
network_square_linnet=as.linnet.SpatialLines(network_square)
network_square_linnet$vertices$n
network_square_linnet$lines$n
plot(intersection_points,add=T,col="black",pch=20,cex=1.8)
dev.off()

# Simplify network

t0=Sys.time()
chicago.linnet <- SimplifyLinearNetwork(chicago.linnet, Angle = 20, Length = 50)
chicago.linnet
t1=Sys.time()
t1-t0
chicago.SpLines <- as.SpatialLines.psp(as.psp(chicago.linnet))

# Figure 2b

setEPS()
postscript(paste0("Figure2b.eps"), family="Times")
par(mar=c(0,0,0,0))

network_square=intersect(chicago.SpLines,square)
plot(network_square,col="#808080")
vertices_network=vertices(chicago.linnet)
vertices_network=as(vertices_network,"SpatialPoints")
intersection_points=intersect(vertices_network,square)
network_square_linnet=as.linnet.SpatialLines(network_square)
network_square_linnet$vertices$n
network_square_linnet$lines$n
plot(intersection_points,add=T,col="black",pch=20,cex=1.8)
dev.off()

###################################################################################################################
# Downloading and preparing crime data from Chicago
###################################################################################################################

# Downloading crime data

chicago.crimes <- crimedata::get_crime_data(years = 2007:2018, cities = "Chicago")
dim(chicago.crimes)
table(chicago.crimes$offense_group)

# Extract year, month and hour of occurrence

chicago.crimes$year <- year(chicago.crimes$date_single)
chicago.crimes$month <- month(chicago.crimes$date_single)
chicago.crimes$hour <- hour(chicago.crimes$date_single)

# Creating a lpp

chicago.crimes.coord <- data.frame(x = chicago.crimes$longitude, y = chicago.crimes$latitude)
coordinates(chicago.crimes.coord) <-~ x + y
lonlat_proj <- "+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0"
utm_proj <- "+proj=utm +zone=16 ellps=WGS84"
proj4string(chicago.crimes.coord) <- lonlat_proj
chicago.crimes.coord <- spTransform(chicago.crimes.coord, utm_proj)
X.chicago <- lpp(data.frame(x = chicago.crimes.coord@coords[,1], 
                            y = chicago.crimes.coord@coords[,2], 
                            offense_against = chicago.crimes$offense_against,
                            year = chicago.crimes$year,
                            month = chicago.crimes$month,
                            hour = chicago.crimes$hour),
                 chicago.linnet)

# Marks frequency

table(X.chicago$data$offense_against)
table(X.chicago$data$year)
table(X.chicago$data$month)
table(X.chicago$data$hour)

# Saving X.chicago

save(X.chicago,file="X.chicago.rda")

###################################################################################################################
# Estimating a relative probability surface
###################################################################################################################

load("X.chicago.rda")
chicago.linnet <- X.chicago$domain
chicago.SpLines <- as.SpatialLines.psp(as.psp(chicago.linnet))

t0=Sys.time()
rel_probs_persons <- relpnet(X = X.chicago, 
                             lixel_length = 50,
                             h = 250,
                             mark = "offense_against",
                             category_mark = "persons") 
t1=Sys.time()
t1-t0
str(rel_probs_persons)

# Figure 3: Testing several h values

t0=Sys.time()
rel_probs_persons_1 <- relpnet(X = X.chicago, 
                               lixel_length = 50,
                               h = 125,
                               mark = "offense_against",
                               category_mark = "persons") 
t1=Sys.time()
t1-t0
plotrelp(X = X.chicago, rel_probs = rel_probs_persons_1, eps_image = T)

rel_probs_persons_2 <- relpnet(X = X.chicago, 
                               lixel_length = 50,
                               h = 250,
                               mark = "offense_against",
                               category_mark = "persons") 
plotrelp(X = X.chicago, rel_probs = rel_probs_persons_2, eps_image = T)

rel_probs_persons_3 <- relpnet(X = X.chicago, 
                               lixel_length = 50,
                               h = 500,
                               mark = "offense_against",
                               category_mark = "persons") 
plotrelp(X = X.chicago, rel_probs = rel_probs_persons_3, eps_image = T)

t0=Sys.time()
rel_probs_persons_4 <- relpnet(X = X.chicago, 
                               lixel_length = 50,
                               h = 1000,
                               mark = "offense_against",
                               category_mark = "persons") 
t1=Sys.time()
t1-t0
plotrelp(X = X.chicago, rel_probs = rel_probs_persons_4, eps_image = T)

###################################################################################################################
# Detecting differential risk hotspots
###################################################################################################################

# Differential risk hotspots for k = 1, n = 30

t0=Sys.time()
hotspots_persons <- drhot(X = X.chicago, rel_prob = rel_probs_persons, k = 1, n = 30)
t1=Sys.time()
t1-t0
str(hotspots_persons)

# Summary differential risk hotspots 

t0=Sys.time()
summary_persons <- drsummary(X = X.chicago, rel_prob = rel_probs_persons, hotspots = hotspots_persons)
t1=Sys.time()
t1-t0
summary_persons[,c("Events type (ctr)", "All events (ctr)", "Prop. (ctr)")]
summary_persons[,c("Length in m (ctr)", "PAI_t (ctr)")]
summary_persons[,c("Events type (ext)", "All events (ext)", "Prop. (ext)")]
summary_persons[,c("Length in m (ext)", "PAI_t (ext)")]

###################################################################################################################
# Assessing the statistical significance of the hotspots
###################################################################################################################

set.seed(123456)
t0=Sys.time()
summary_persons_p_value <- drsummary(X = X.chicago, rel_prob = rel_probs_persons, hotspots = hotspots_persons, 
                                     n_it = 200, compute_p_value = T)
t1=Sys.time()
t1-t0
summary_persons_p_value$`p-value`
save(summary_persons_p_value,file="summary_persons_p_value.rda")

###################################################################################################################
# Choosing k and n
###################################################################################################################

# Testing several combinations of k and n 

k=0.5;n=20
hotspots_1 <- drhot(X = X.chicago,rel_probs_persons_2,k,n)
print(hotspots_1$PAI)
plothot(X = X.chicago, hotspots = hotspots_1, eps_image = T)

k=1.5;n=20
hotspots_2 <- drhot(X = X.chicago,rel_probs_persons_2,k,n)
print(hotspots_2$PAI)
plothot(X = X.chicago, hotspots_2, eps_image = T)

k=1;n=10
hotspots_3 <- drhot(X = X.chicago,rel_probs_persons_2,k,n)
print(hotspots_3$PAI)
plothot(X = X.chicago, hotspots_3, eps_image = T)

k=1;n=30
hotspots_4 <- drhot(X = X.chicago,rel_probs_persons_2,k,n)
print(hotspots_4$PAI)
plothot(X = X.chicago, hotspots_4, eps_image = T)

# Sensitivity analysis

sensitivity_analysis <- drsens(X = X.chicago, rel_prob = rel_probs_persons, 
                               ks = seq(0,3,0.5), 
                               ns = seq(10,30,5))
save(sensitivity_analysis, file = "sensitivity_analysis.rda")

###################################################################################################################
# Other applications of the methodology
###################################################################################################################

# New marks 

year_after_2012 <- ifelse(X.chicago$data$year>2012, "Yes", "No")
month_winter <- ifelse(X.chicago$data$month%in%c(12,1,2), "Yes", "No")
hour_21_3 <- ifelse(X.chicago$data$hour%in%c(21:23,0:3), "Yes", "No")
marks(X.chicago) <- data.frame(as.data.frame(marks(X.chicago)),
                               year_after_2012 = year_after_2012,
                               month_winter = month_winter,
                               hour_21_3 = hour_21_3)

# Estimating a relative probability surface 

rel_probs_after_2012 <- relpnet(X = X.chicago, 
                                lixel_length = 50,
                                h = 250,
                                mark = "year_after_2012",
                                category_mark = "Yes") 
str(rel_probs_after_2012)

rel_probs_winter <- relpnet(X = X.chicago, 
                            lixel_length = 50,
                            h = 250,
                            mark = "month_winter",
                            category_mark = "Yes") 
str(rel_probs_winter)

rel_probs_21_3 <- relpnet(X = X.chicago, 
                          lixel_length = 50,
                          h = 250,
                          mark = "hour_21_3",
                          category_mark = "Yes") 
str(rel_probs_21_3)

# Sensitivity analyses

sensitivity_after_2012 <- drsens(X = X.chicago, 
                                 rel_prob = rel_probs_after_2012, 
                                 ks = seq(0,3,0.5), 
                                 ns = seq(10,30,5))
sensitivity_after_2012
save(sensitivity_after_2012, file = "sensitivity_after_2012.rda")


sensitivity_winter <- drsens(X = X.chicago, 
                             rel_prob = rel_probs_winter, 
                             ks = seq(0,3,0.5), 
                             ns = seq(10,30,5))
sensitivity_winter
save(sensitivity_winter, file = "sensitivity_winter.rda")


sensitivity_21_3 <- drsens(X = X.chicago, 
                           rel_prob = rel_probs_21_3, 
                           ks = seq(0,3,0.5), 
                           ns = seq(10,30,5))
sensitivity_21_3
save(sensitivity_21_3, file = "sensitivity_rel_probs_21_3.rda")

# Hotspots and maps

hotspots_after_2012 <- drhot(X = X.chicago, rel_prob = rel_probs_after_2012, k = 1, n = 30)
plothot(X = X.chicago, hotspots_after_2012, eps_image = T)

hotspots_winter <- drhot(X = X.chicago, rel_prob = rel_probs_winter, k = 1.5, n = 15)
plothot(X = X.chicago, hotspots_winter, eps_image = T)

hotspots_21_3 <- drhot(X = X.chicago, rel_prob = rel_probs_21_3, k = 0, n = 30)
plothot(X = X.chicago, hotspots_21_3, eps_image = T)
