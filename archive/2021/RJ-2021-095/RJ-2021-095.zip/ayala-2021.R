## The following R script includes the examples for the paper "openSkies -
## Integration of Aviation Data into the R Ecosystem".
## Given that some examples require registration in the OpenSky Network
## and authorization to access the Impala shell, the results of such
## function calls are also provided as .rds files, which can be loaded
## to avoid the need to obtain the data through calls to the OpenSky
## Network Impala shell.

library("openSkies")

## Example 1

## In the following example, we retrieve information about all flights
## that departed from Frankfurt Airport the 29th of January 2018 after 12 pm.
## It should be noted that such large requests can take a long time unless
## performed with the Impala shell
## It should also be noted that, in this and the following examples, the
## values for the username and password arguments should be substituted with
## personal credentials registered at the OpenSky Network
flights_frankfurt <- getAirportArrivals(airport="EDDF", startTime="2018-01-29 12:00:00", 
                                        endTime="2018-01-29 24:00:00", timeZone="Europe/Berlin",
                                        includeStateVectors = TRUE, timeResolution = 60,
                                        useImpalaShell = TRUE, username = "user",
                                        password = "password")

## We can then easily check the amount of flights
length(flights_frankfurt) # 316 flights

## The results can also be loaded from an .rds file:
flights_frankfurt <- readRDS(file="rds_files/frankfurt_flights.rds")

## We can then easily check the amount of flights
length(flights_frankfurt)

## Trajectories of the 316 flights can be obtained by retrieving
## the set of state vectors of each flight
trajectories_frankfurt <- lapply(flights_frankfurt, function(f) f$state_vectors)

## It is also possible to retrieve all state vectors received from a 
## given aircraft in a given period of time. In the following example, we
## obtain all the state vectors received for aircraft with ICAO24 code
## 403003 between 12 PM of the 8th of October, 2020 and 6 PM of the 
## 9th of October, 2020
stateVectors_403003 <- getAircraftStateVectorsSeries("403003", startTime = "2020-10-08 12:00:00", 
                                                     endTime = "2020-10-09 18:00:00", 
                                                     timeZone="Europe/London",
                                                     timeResolution = 60,                         
                                                     useImpalaShell = TRUE, 
                                                     username = "user",
                                                     password = "password")

## The results can also be loaded from an .rds file:
stateVectors_403003 <- readRDS(file="rds_files/403003_vectors.rds")

## The ensemble of state vectors can then be split into individual
## flight instances, revealing that the aircraft performed 6 flights
## in the analyzed period
flights_403003 <- stateVectors_403003$split_into_flights()
length(flights_403003) # 6 flights

## Let us get some additional information about the flights performed by
## this aircraft. For example, the maximum speed that it reached in km/h
maxSpeed <- max(stateVectors_403003$get_values("velocity", removeNAs = TRUE))/1000*3600

## The maximum speed that it reached is just above 210 km/h. This is well below 
## the speed typically used by commercial passenger jets, usually around 800 km/h
## Investigation of the aircraft model confirms that it is indeed a small CESSNA 152
aircraftData <- getAircraftMetadata("403003", maxQueryAttempts = 3)
aircraftData$model

## Example 2

## In the following example, we visualize the flights performed by the
## CESSNA 152 identified in example 1.
## First, let us obtain the trajectories of the flights performed
## by the CESSNA 152
trajectories_CESSNA152 <- lapply(flights_403003, function(f) f$state_vectors)

## Then, we create a color palette
library(viridis)
colors <- magma(length(trajectories_CESSNA152))

## Then, the trajectories are plotted
plotRoutes(trajectories_CESSNA152, pathColors = colors, lineSize = 1.2,
           lineAlpha = 0.8, includeArrows = TRUE,
           paddingFactor = 0.05)

## Example 3

## In this example, we visualize all the planes flying over Switzerland
## at a given time
## Firstly we retrieve the state vectors of all aircraft flying over Switzerland
## the 2nd of March, 2018 at 14.30 (London time)
vectors_switzerland <- getSingleTimeStateVectors(time="2018-03-02 14:30:00", 
                                                 timeZone="Europe/London", 
                                                 minLatitude=45.8389,
                                                 maxLatitude=47.8229, 
                                                 minLongitude=5.9962, 
                                                 maxLongitude=10.5226, 
                                                 username="user", 
                                                 password="password", 
                                                 useImpalaShell = TRUE)

## The results can also be loaded from an .rds file:
vectors_switzerland <- readRDS(file="rds_files/switzerland_vectors.rds")

## Then, the aircraft are plotted
plotPlanes(vectors_switzerland)

## Example 4

## In this example, we cluster the previously retrieved flights that departed
## from Frankfurt airport
## As an example, let´s cluster the 316 flights departing into 8 clusters with 
## the k-means algorithm
set.seed(1) # Seed is set to ensure reproducibility of the ordering of clusters
clusters = clusterRoutes(trajectories_frankfurt, "kmeans", numberClusters = 8)

## The results can be visualized with plotRoutes
plotRoutes(trajectories_frankfurt, pathColors = clusters$cluster, 
           literalColors = FALSE, paddingFactor = 0.1)

## The clusters differ in their broad area of destination. For example,
## clusters 1, 3 and 6 comprise mostly flights to North America, Japan and
## central Asia respectively. Due to their geographical proximity, it is expected
## that flights from cluster 3 are closer to flights from cluster 6 than
## to those assigned to cluster 1. Let us confirm this:
flights_frankfurt[clusters$cluster==3][[1]]$distance_to_flight(flights_frankfurt[clusters$cluster==6][[1]])
## Returns 123.3449
flights_frankfurt[clusters$cluster==3][[1]]$distance_to_flight(flights_frankfurt[clusters$cluster==1][[1]])
## Returns 348.4957

## The shorter distance between flights of clusters 5 and 6 is in accordance with
## the expectations.
